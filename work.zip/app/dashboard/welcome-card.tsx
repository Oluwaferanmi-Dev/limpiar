import { Button } from "@/components/ui/button"

export function WelcomeCard() {
  return (
    <div className="rounded-xl overflow-hidden bg-gradient-to-r from-[#0082ed] to-[#add7f9] text-white p-8 relative">
      <div className="max-w-lg">
        <h1 className="text-4xl font-semibold mb-4">Welcome, William!</h1>
        <p className="text-lg opacity-90 mb-6">Let's go ahead and add your first property to get you started.</p>
        <Button variant="secondary" className="bg-white text-blue-600 hover:bg-white/90">
          Add property
        </Button>
      </div>
      <div className="absolute right-0 bottom-0 w-[400px]">
        <img src="/placeholder.svg?height=300&width=400" alt="Building" className="object-cover" />
      </div>
    </div>
  )
}

